class Calculadora{
	constructor(){
		this.operando1 = 0;
		this.operando2 = 0;
		this.operacion = 0; // 1-> + ; 2-> - ; 3-> * ; 4-> / ;
	}
}